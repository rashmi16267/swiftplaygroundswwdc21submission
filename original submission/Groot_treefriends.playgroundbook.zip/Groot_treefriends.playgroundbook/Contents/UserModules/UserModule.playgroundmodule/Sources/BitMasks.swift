
public struct Bitmasks {
    static let groot: UInt32 = 1 << 1
    static let termite: UInt32 = 1 << 2
    static let healthyTree: UInt32 = 1 << 3
}
