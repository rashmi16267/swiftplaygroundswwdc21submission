import SpriteKit
public class GameScene: SKScene, SKPhysicsContactDelegate {
    
    let numberOftrees = 5
    let maxhealthytreeSpeed: UInt32 = 100
    var dLength: CGFloat = 1.5
    
    var gameOver = false
    var movingGroot = false
    var offset: CGPoint!
    
    var groot: SKSpriteNode!
    var healthytrees = [SKSpriteNode]()
    
    func positionWithin(range: CGFloat, containerSize: CGFloat) -> CGFloat {
        let A = CGFloat(arc4random_uniform(100))/100.0
        let C = (containerSize * (1.0 - range))
        let B = (containerSize * range + C)
        return A * B
    }
    
    func distanceFrom(posA: CGPoint, posB: CGPoint) -> CGFloat {
        let aSqr = (posA.x - posB.x)*(posA.x - posB.x)
        let bSqr = (posA.y - posB.y)*(posA.y - posB.y)
        return sqrt(aSqr + bSqr)
    }
    
    public override func didMove(to view: SKView) {
        dLength /= 2.0
        
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsBody?.friction = 0.0
        physicsWorld.contactDelegate = self
        
        let bg = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "file.png")))
        bg.setScale(2.0)
        bg.zPosition = -10
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(bg)
        
        groot = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "groot_stance.png"))) 
        groot.setScale(0.1)
        groot.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(groot)
        
        groot.physicsBody = SKPhysicsBody(circleOfRadius: groot.size.width * (0.5 * dLength))
        groot.physicsBody?.isDynamic = false
        groot.physicsBody?.categoryBitMask = Bitmasks.healthyTree
        groot.physicsBody?.contactTestBitMask = Bitmasks.termite
        groot.physicsBody?.friction = 0.0
        groot.physicsBody?.angularDamping = 0.0
        groot.physicsBody?.restitution = 1.1
        groot.physicsBody?.allowsRotation = false
        
        
        for _ in 1...numberOftrees{
            createHealthytree()
        }
        
        for healthytree in healthytrees {
            healthytree.physicsBody?.applyImpulse(CGVector(dx: CGFloat(CGFloat(arc4random_uniform(maxhealthytreeSpeed)) - (CGFloat(maxhealthytreeSpeed) * 0.5)), dy: CGFloat(CGFloat(arc4random_uniform(maxhealthytreeSpeed)) - (CGFloat(maxhealthytreeSpeed) * 0.5))))
        }
        
        
        
    }
    
    func createHealthytree() {
        let healthytree = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "tree.png")))
        healthytree.setScale(0.3)
        healthytree.position = CGPoint(x: positionWithin(range: 0.08, containerSize: size.width), y: positionWithin(range: 0.0, containerSize: size.height))
        
            /*
        while distanceFrom(posA: deadtree.position, posB: deadtree.position) < deadtree.size.width * dLength * 5 {
            deadtree.position = CGPoint(x: positionWithin(range: 0.08, containerSize: size.width), y: positionWithin(range: 0.0, containerSize: size.height))
        }
 */
        
        addChild(healthytree)
        healthytrees.append(healthytree)
        
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !gameOver else { return }
        guard let touch = touches.first else { return }
        let touchLoc = touch.location(in: self)
        let touchedNodes = nodes(at: touchLoc)
        
        for node in touchedNodes {
                if node == groot {
                    movingGroot = true
                    offset = CGPoint(x: touchLoc.x - groot.position.x, y: touchLoc.y - groot.position.y)
                }
            }
        }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !gameOver && movingGroot else { return }
        guard let touch = touches.first else { return }
        let touchLoc = touch.location(in: self)
        let newGrootPos = CGPoint(x: touchLoc.x - offset.x, y: touchLoc.y - offset.y)
        
        groot.run(SKAction.move(to: newGrootPos, duration: 0.1))
    }
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        movingGroot = false
    }
    
    }
    


