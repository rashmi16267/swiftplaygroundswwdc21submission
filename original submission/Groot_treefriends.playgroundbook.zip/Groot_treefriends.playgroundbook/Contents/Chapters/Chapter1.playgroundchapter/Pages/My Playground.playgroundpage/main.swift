import PlaygroundSupport
import UIKit
import SpriteKit

let skView = SKView(frame: .zero)
let gameScene = GameScene(size: UIScreen.main.bounds.size)
gameScene.scaleMode = .aspectFill 
skView.presentScene(gameScene)

skView.preferredFramesPerSecond = 80

PlaygroundPage.current.liveView = skView
PlaygroundPage.current.wantsFullScreenLiveView = true 

